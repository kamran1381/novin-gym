import React from 'react'
import Loginform from '@/components/loginform/loginform'
function Login() {
  return (
    <div className='bg-[#000000] min-h-screen '>
        <Loginform/>
    </div>
  )
}

export default Login