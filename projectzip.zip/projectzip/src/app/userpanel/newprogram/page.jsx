import React from 'react'
import Sidebar from '@/components/userpanel/sidebar'
import Programform from '@/components/userpanel/programform'
function NewProgram() {
  return (
    <div className='bg-[#000000]   min-h-screen'>
    <div className=''>
       
            <Programform/>
    </div>
</div>
  )
}

export default NewProgram