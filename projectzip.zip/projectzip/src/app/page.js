import Image from "next/image";
import Sectionone from "./home/sectionone";
export default function Home() {
  return (
    <div className="">
       <Sectionone/>
    </div>
   
  );
}
