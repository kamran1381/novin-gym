import React from 'react'

function Next() {
    return (
        <svg width="20" height="20" viewBox="0 0 22 23" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M13.8325 7.48L7.85585 13.4567C7.15002 14.1625 7.15002 15.3175 7.85585 16.0233L13.8325 22" stroke="#F9F9F9" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round" />
        </svg>

    )
}

export default Next